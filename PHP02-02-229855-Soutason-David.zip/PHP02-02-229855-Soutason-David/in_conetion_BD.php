<?php
#connection
$mysqli = new mysqli('localhost','root','','projet_ecommerce');

 ?>
