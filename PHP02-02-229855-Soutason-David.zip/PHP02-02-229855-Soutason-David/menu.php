<?php



?>
<header>
  <div class="logo">

  </div>

  <nav>
    <ul>
      <li> <a href="index.php"> Accueil </a> </li>
      <li> <a href="Notproduit.php"> Not Produit </a> </li>

      <li class="deroulant"> <a href="#">Inscription & Connection <br>&ensp;</a>
        <ul class="sous">
          <li > <a href="NewClient.php"> Nouveau Client </a> </li>
          <li > <a href="Connection.php"> Connection </a> </li>
          <li > <a href="deconnection.php"> Deconnection </a> </li>
        </ul>
      </li>

      <li class="deroulant"><a href="#">Mom Panier 1&2<br>&ensp;</a>
        <ul class="sous">
          <li> <a href="MonPanier.php"> Mom Panier </a> </li>
          
        </ul>
        <li>

        </ul>
      </nav>

    </header>
