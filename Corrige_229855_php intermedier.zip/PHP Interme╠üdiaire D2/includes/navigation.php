<nav>
    <ul>
        <li><a href="index.php">Accueil</a></li>
        <li><a href="cart.php">Panier</a></li>
        <li><a href="logout.php">Déconnexion</a></li>
    </ul>
</nav>
